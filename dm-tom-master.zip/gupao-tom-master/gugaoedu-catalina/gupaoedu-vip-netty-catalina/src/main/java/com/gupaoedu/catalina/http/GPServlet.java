package com.gupaoedu.catalina.http;

public abstract class GPServlet {
	
	public void doGet(GPRequest request,GPResponse response){}
	
	public void doPost(GPRequest request,GPResponse response){}
}
