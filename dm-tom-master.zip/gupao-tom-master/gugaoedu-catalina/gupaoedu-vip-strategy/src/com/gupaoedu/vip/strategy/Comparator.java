package com.gupaoedu.vip.strategy;

//�Ƚ���
public interface Comparator {
	
	int compareTo(Object obj1,Object obj2);
	
}
