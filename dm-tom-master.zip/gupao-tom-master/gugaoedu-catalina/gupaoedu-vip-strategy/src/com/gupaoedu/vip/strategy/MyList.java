package com.gupaoedu.vip.strategy;

public class MyList {
	
	public void sort(Comparator com){
//		com.compareTo(obj1, obj2);
		System.out.println("执行逻辑");
	}
	
}
