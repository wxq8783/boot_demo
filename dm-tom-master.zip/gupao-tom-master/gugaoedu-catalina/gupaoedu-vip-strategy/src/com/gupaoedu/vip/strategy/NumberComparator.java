package com.gupaoedu.vip.strategy;

public class NumberComparator implements Comparator{

	@Override
	public int compareTo(Object obj1, Object obj2) {
		return 0;
	}

}
