package com.gupaoedu.vip.strategy;

public class ObjectComparator implements Comparator{

	@Override
	public int compareTo(Object obj1, Object obj2) {
		return 0;
	}

}
