package com.gupaoedu.demo.service;

public interface IModifyService {

	public String add(String name,String addr);
	public String remove(Integer id);
	
}
