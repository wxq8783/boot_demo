package com.gupaoedu.demo.service;

public interface IQueryService {

	public String search(String name);
	
}
