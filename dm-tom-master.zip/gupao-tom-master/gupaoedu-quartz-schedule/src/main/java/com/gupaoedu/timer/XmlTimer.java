package com.gupaoedu.timer;

import org.apache.log4j.Logger;


public class XmlTimer {
	Logger LOG = Logger.getLogger(this.getClass());
	public void execute(){
		LOG.info("xml配置的任务执行");
	}
	
}
