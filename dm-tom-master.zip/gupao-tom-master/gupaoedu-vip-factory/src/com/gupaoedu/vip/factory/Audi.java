package com.gupaoedu.vip.factory;

public class Audi implements Car{

	@Override
	public String getName() {
		return "Audi";
	}

}
