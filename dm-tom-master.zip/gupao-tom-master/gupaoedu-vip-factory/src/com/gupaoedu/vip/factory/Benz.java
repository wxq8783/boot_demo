package com.gupaoedu.vip.factory;

public class Benz implements Car{

	@Override
	public String getName() {
		return "Benz";
	}

}
