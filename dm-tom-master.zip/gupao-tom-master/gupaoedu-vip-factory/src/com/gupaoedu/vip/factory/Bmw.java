package com.gupaoedu.vip.factory;

public class Bmw implements Car{

	@Override
	public String getName() {
		return "BMW";
	}

}
