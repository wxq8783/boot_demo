package com.gupaoedu.vip.mvc.demo.service;

public interface INamedService {

}
