package com.gupaoedu.vip.mvc.demo.service;

public interface IService {

}
