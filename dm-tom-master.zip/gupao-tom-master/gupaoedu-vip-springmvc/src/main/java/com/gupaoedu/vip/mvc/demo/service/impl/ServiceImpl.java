package com.gupaoedu.vip.mvc.demo.service.impl;

import com.gupaoedu.vip.mvc.demo.service.IService;
import com.gupaoedu.vip.mvc.framework.annotation.GPService;

@GPService
public class ServiceImpl implements IService{

}
